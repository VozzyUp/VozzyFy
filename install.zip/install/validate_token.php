<?php
/**
 * Endpoint para validar token do GitHub
 * Retorna JSON para processamento via AJAX
 */

session_start();

header('Content-Type: application/json');

// Verificar se é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

// Verificar se token foi enviado
if (empty($_POST['github_token'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Token não fornecido']);
    exit;
}

$githubToken = trim($_POST['github_token']);

// Validar token testando conexão com GitHub
$githubRepo = 'LeonardoIsrael0516/getfy';
$githubBranch = 'main';
$url = "https://api.github.com/repos/{$githubRepo}/contents/VERSION.txt?ref={$githubBranch}";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'User-Agent: PHP-Installer',
    'Authorization: token ' . $githubToken,
    'Accept: application/vnd.github.v3.raw'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($httpCode === 200) {
    // Token válido, salvar na sessão
    $_SESSION['install_github'] = [
        'token' => $githubToken
    ];
    echo json_encode([
        'success' => true,
        'message' => 'Token válido',
        'redirect' => '/install?step=3'
    ]);
} else {
    // Token inválido
    $errorMsg = 'Token inválido ou sem permissões.';
    if ($httpCode === 401) {
        $errorMsg = 'Token inválido. Verifique se o token está correto.';
    } elseif ($httpCode === 403) {
        $errorMsg = 'Token sem permissões. Verifique se o token tem permissão "repo".';
    } elseif ($httpCode === 404) {
        $errorMsg = 'Repositório não encontrado. Verifique se o repositório está correto.';
    }
    
    echo json_encode([
        'success' => false,
        'error' => $errorMsg,
        'http_code' => $httpCode
    ]);
}

