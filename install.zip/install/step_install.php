<?php
/**
 * Passo 4: Processamento da Instalação
 */

// Validar dados (sessão já iniciada no index.php)
// Verificar se os dados necessários estão na sessão
if (empty($_SESSION['install_db'])) {
    // Se não tem dados do banco, voltar para o passo 3
    header('Location: /install?step=3');
    exit;
}

if (empty($_SESSION['install_github'])) {
    // Se não tem dados de acesso, voltar para o passo 2
    header('Location: /install?step=2');
    exit;
}

$dbConfig = $_SESSION['install_db'];
// Dados de admin (obrigatórios agora)
$adminData = $_SESSION['install_admin'] ?? [];

// Processar instalação via AJAX
?>
<div class="space-y-6">
    <h2 class="text-2xl font-semibold text-gray-900">Instalando Sistema...</h2>
    <p class="text-gray-600">Por favor, aguarde enquanto o sistema é instalado.</p>
    
    <div id="install-progress" class="space-y-4">
        <div class="bg-gray-100 rounded-lg p-4">
            <div class="flex items-center space-x-3">
                <div class="animate-spin rounded-full h-5 w-5 border-b-2 border-purple-600"></div>
                <span id="status-text" class="text-gray-700">Iniciando instalação...</span>
            </div>
        </div>
        
        <div class="bg-gray-200 rounded-full h-2">
            <div id="progress-bar" class="bg-purple-600 h-2 rounded-full transition-all duration-300" style="width: 0%"></div>
        </div>
        
        <div id="install-log" class="bg-gray-50 rounded-lg p-4 max-h-64 overflow-y-auto space-y-2 text-sm font-mono">
            <!-- Log será preenchido via JavaScript -->
        </div>
    </div>
    
    <div id="install-success" class="hidden">
        <div class="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
            <div class="text-green-600 text-5xl mb-4">✓</div>
            <h3 class="text-xl font-semibold text-green-800 mb-2">Instalação Concluída!</h3>
            <p class="text-green-700 mb-4">O sistema foi instalado com sucesso.</p>
            <a href="/login" class="inline-block bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-lg transition">
                Ir para Login →
            </a>
        </div>
    </div>
    
    <div id="install-error" class="hidden">
        <div class="bg-red-50 border border-red-200 rounded-lg p-6">
            <h3 class="text-xl font-semibold text-red-800 mb-2">Erro na Instalação</h3>
            <p id="error-message" class="text-red-700 mb-4"></p>
            <a href="/install?step=3" class="inline-block bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition">
                Tentar Novamente
            </a>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const statusText = document.getElementById('status-text');
    const progressBar = document.getElementById('progress-bar');
    const installLog = document.getElementById('install-log');
    const installSuccess = document.getElementById('install-success');
    const installError = document.getElementById('install-error');
    
    function addLog(message, type = 'info') {
        const logEntry = document.createElement('div');
        logEntry.className = type === 'error' ? 'text-red-600' : (type === 'success' ? 'text-green-600' : 'text-gray-700');
        logEntry.textContent = '[' + new Date().toLocaleTimeString() + '] ' + message;
        installLog.appendChild(logEntry);
        installLog.scrollTop = installLog.scrollHeight;
    }
    
    function updateProgress(percent, text) {
        progressBar.style.width = percent + '%';
        statusText.textContent = text;
    }
    
    // Dados da instalação
    const installData = {
        github: <?php echo json_encode($_SESSION['install_github']); ?>,
        db: <?php echo json_encode($dbConfig); ?>,
        admin: <?php echo json_encode($adminData); ?>
    };
    
    // Iniciar instalação
    fetch('/install/installer.php?action=install', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(installData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateProgress(100, 'Instalação concluída!');
            addLog('Instalação concluída com sucesso!', 'success');
            setTimeout(() => {
                document.getElementById('install-progress').classList.add('hidden');
                installSuccess.classList.remove('hidden');
            }, 1000);
        } else {
            throw new Error(data.error || 'Erro desconhecido');
        }
    })
    .catch(error => {
        addLog('Erro: ' + error.message, 'error');
        document.getElementById('error-message').textContent = error.message;
        document.getElementById('install-progress').classList.add('hidden');
        installError.classList.remove('hidden');
    });
    
    // Simular progresso durante instalação
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += 5;
        if (progress <= 90) {
            if (progress < 30) {
                updateProgress(progress, 'Baixando código... ' + progress + '%');
            } else if (progress < 60) {
                updateProgress(progress, 'Configurando sistema... ' + progress + '%');
            } else {
                updateProgress(progress, 'Instalando banco de dados... ' + progress + '%');
            }
        }
    }, 300);
});
</script>

