<?php
/**
 * Passo 1: Verificação de Requisitos
 */

$errors = $checker->getErrors();
$warnings = $checker->getWarnings();
$requirements = $checker->getRequirements();
$isReady = $checker->isReady();
?>

<div class="space-y-6">
    <h2 class="text-2xl font-semibold text-gray-900">Verificação de Requisitos do Sistema</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4">
            <h3 class="text-red-800 font-semibold mb-2">Erros Encontrados:</h3>
            <ul class="list-disc list-inside text-red-700 space-y-1">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($warnings)): ?>
        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 class="text-yellow-800 font-semibold mb-2">Avisos:</h3>
            <ul class="list-disc list-inside text-yellow-700 space-y-1">
                <?php foreach ($warnings as $warning): ?>
                    <li><?php echo htmlspecialchars($warning); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <!-- Detalhes dos Requisitos -->
    <div class="space-y-4">
        <!-- Versão PHP -->
        <?php if (isset($requirements['php_version'])): ?>
            <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <div>
                    <span class="font-medium">Versão PHP</span>
                    <p class="text-sm text-gray-600">Versão atual: <?php echo htmlspecialchars($requirements['php_version']['current']); ?></p>
                </div>
                <span class="text-green-600 font-semibold">✓ OK</span>
            </div>
        <?php endif; ?>
        
        <!-- Extensões PHP -->
        <?php if (isset($requirements['extensions'])): ?>
            <div class="p-3 bg-green-50 rounded-lg">
                <span class="font-medium block mb-2">Extensões PHP</span>
                <div class="grid grid-cols-2 gap-2">
                    <?php foreach ($requirements['extensions'] as $ext => $info): ?>
                        <div class="flex items-center justify-between">
                            <span class="text-sm"><?php echo htmlspecialchars($info['name']); ?></span>
                            <span class="text-green-600">✓</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Diretórios -->
        <?php if (isset($requirements['directories'])): ?>
            <div class="p-3 bg-green-50 rounded-lg">
                <span class="font-medium block mb-2">Permissões de Diretórios</span>
                <div class="space-y-1">
                    <?php foreach ($requirements['directories'] as $dir => $info): ?>
                        <div class="flex items-center justify-between">
                            <span class="text-sm"><?php echo htmlspecialchars($info['name']); ?></span>
                            <span class="text-green-600">✓ Gravável</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Botões de Navegação -->
    <div class="flex justify-end space-x-4 pt-6">
        <?php if ($isReady): ?>
            <a href="/install?step=2" class="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-6 rounded-lg transition">
                Próximo Passo →
            </a>
        <?php else: ?>
            <button disabled class="bg-gray-300 text-gray-500 font-medium py-2 px-6 rounded-lg cursor-not-allowed">
                Corrija os erros acima
            </button>
        <?php endif; ?>
    </div>
</div>

