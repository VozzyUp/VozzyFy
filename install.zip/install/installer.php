<?php
/**
 * Processador de Instalação
 * Processa a instalação completa do sistema
 */

header('Content-Type: application/json');

// Verificar se já está instalado
$lockFile = dirname(__DIR__) . '/config/installed.lock';
if (file_exists($lockFile)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Sistema já está instalado']);
    exit;
}

$action = $_GET['action'] ?? '';

// Função para retornar resposta JSON
function jsonResponse($success, $data = [], $error = null) {
    http_response_code($success ? 200 : 500);
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'error' => $error
    ], JSON_PRETTY_PRINT);
    exit;
}

/**
 * Deleta um diretório recursivamente
 */
function delete_directory_recursive($dir) {
    if (!is_dir($dir)) {
        return false;
    }
    
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        if (is_dir($path)) {
            delete_directory_recursive($path);
        } else {
            unlink($path);
        }
    }
    return rmdir($dir);
}

// Teste de conexão com banco de dados
if ($action === 'test_connection') {
    $db_host = $_POST['db_host'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    
    if (empty($db_host) || empty($db_user) || empty($db_name)) {
        jsonResponse(false, [], 'Campos obrigatórios não preenchidos');
    }
    
    try {
        // Tentar conectar sem especificar o banco primeiro
        $pdo = new PDO("mysql:host={$db_host};charset=utf8mb4", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Verificar se o banco existe, se não, criar
        $stmt = $pdo->query("SHOW DATABASES LIKE '{$db_name}'");
        if ($stmt->rowCount() === 0) {
            $pdo->exec("CREATE DATABASE `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }
        
        // Conectar ao banco específico
        $pdo = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8mb4", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        jsonResponse(true, ['message' => 'Conexão bem-sucedida']);
        
    } catch (PDOException $e) {
        jsonResponse(false, [], 'Erro ao conectar: ' . $e->getMessage());
    }
}

// Processamento completo da instalação
if ($action === 'install') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || empty($input['db']) || empty($input['github'])) {
        jsonResponse(false, [], 'Dados de instalação inválidos');
    }
    
    $githubConfig = $input['github'];
    $dbConfig = $input['db'];
    // Admin é opcional - se não fornecido, usa padrão do banco
    $adminData = $input['admin'] ?? [];
    
    // Valores padrão
    $defaultRepo = 'LeonardoIsrael0516/getfy';
    $defaultBranch = 'main';
    
    try {
        // 0. Baixar código
        $githubRepo = $defaultRepo;
        $githubToken = $githubConfig['token'] ?? '';
        $githubBranch = $defaultBranch;
        
        if (empty($githubToken)) {
            throw new Exception('Token de acesso é obrigatório');
        }
        
        // Baixar código usando zipball
        $zipballUrl = "https://api.github.com/repos/{$githubRepo}/zipball/{$githubBranch}";
        $tempZip = sys_get_temp_dir() . '/install_' . uniqid() . '.zip';
        
        $ch = curl_init($zipballUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'User-Agent: PHP-Installer',
            'Authorization: token ' . $githubToken,
            'Accept: application/vnd.github.v3+json'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        $zipContent = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        if ($httpCode !== 200 || empty($zipContent)) {
            throw new Exception("Erro ao baixar código. HTTP {$httpCode}. " . ($curlError ?: 'Sem resposta'));
        }
        
        // Salvar ZIP temporário
        file_put_contents($tempZip, $zipContent);
        
        // Verificar se ZipArchive está disponível
        if (!class_exists('ZipArchive')) {
            throw new Exception('Extensão ZipArchive não está disponível. Habilite a extensão zip no php.ini');
        }
        
        // Extrair ZIP
        $zip = new ZipArchive();
        if ($zip->open($tempZip) !== TRUE) {
            throw new Exception('Não foi possível abrir o arquivo ZIP baixado');
        }
        
        $extractDir = sys_get_temp_dir() . '/install_extract_' . uniqid();
        mkdir($extractDir, 0755, true);
        
        $zip->extractTo($extractDir);
        $zip->close();
        
        // Encontrar o diretório raiz do repositório (geralmente tem formato: usuario-repositorio-hash)
        $extractedDirs = scandir($extractDir);
        $repoRoot = null;
        foreach ($extractedDirs as $dir) {
            if ($dir !== '.' && $dir !== '..' && is_dir($extractDir . '/' . $dir)) {
                $repoRoot = $extractDir . '/' . $dir;
                break;
            }
        }
        
        if (!$repoRoot) {
            throw new Exception('Não foi possível encontrar o diretório raiz do repositório');
        }
        
        // Copiar arquivos para o diretório de instalação
        $basePath = dirname(__DIR__);
        // Excluir apenas pastas que não devem ser sobrescritas ou que são temporárias
        $excludeDirs = ['backups', 'temp', 'install', '.git'];
        // Arquivos específicos que não devem ser sobrescritos
        $excludeFiles = ['config/config.php']; // config.php já foi criado pelo instalador
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($repoRoot, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        $filesCopied = 0;
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $relativePath = str_replace($repoRoot . DIRECTORY_SEPARATOR, '', $file->getPathname());
                
                // Normalizar separadores de diretório
                $relativePath = str_replace('\\', '/', $relativePath);
                
                // Verificar se está em diretório excluído
                $shouldExclude = false;
                foreach ($excludeDirs as $exclude) {
                    $excludeNormalized = str_replace('\\', '/', $exclude);
                    if (strpos($relativePath, $excludeNormalized . '/') === 0 || $relativePath === $excludeNormalized) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                // Verificar se é arquivo específico que não deve ser sobrescrito
                if (!$shouldExclude) {
                    foreach ($excludeFiles as $excludeFile) {
                        $excludeFileNormalized = str_replace('\\', '/', $excludeFile);
                        if ($relativePath === $excludeFileNormalized) {
                            $shouldExclude = true;
                            break;
                        }
                    }
                }
                
                if ($shouldExclude) {
                    continue;
                }
                
                $destPath = $basePath . '/' . $relativePath;
                $destDir = dirname($destPath);
                
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0755, true);
                }
                
                if (copy($file->getPathname(), $destPath)) {
                    $filesCopied++;
                } else {
                    error_log("Aviso: Não foi possível copiar arquivo: {$relativePath}");
                }
            }
        }
        
        error_log("Arquivos copiados durante instalação: {$filesCopied}");
        
        // Limpar arquivos temporários
        unlink($tempZip);
        delete_directory_recursive($extractDir);
        
        // 1. Criar arquivo config.php
        $configPath = dirname(__DIR__) . '/config/config.php';
        $configTemplate = <<<'PHP'
<?php

define('DB_HOST', '{DB_HOST}');
define('DB_USER', '{DB_USER}');
define('DB_PASS', '{DB_PASS}');
define('DB_NAME', '{DB_NAME}');

// Define o fuso horário padrão para o PHP para 'America/Sao_Paulo' (Horário de Brasília)
date_default_timezone_set('America/Sao_Paulo');

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Define o fuso horário da sessão do MySQL para UTC-03:00 (Horário de Brasília)
    $pdo->exec("SET time_zone = '-03:00';");
} catch (PDOException $e) {
    die("ERRO: Não foi possível conectar ao banco de dados. " . $e->getMessage());
}

// Inicia a sessão para todas as páginas do painel
if (session_status() == PHP_SESSION_NONE) {
    $session_lifetime = 604800; // 7 dias em segundos
    ini_set('session.cookie_lifetime', $session_lifetime);
    ini_set('session.gc_maxlifetime', $session_lifetime);
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_samesite', 'Lax');
    
    if ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
        $_SERVER['SERVER_PORT'] == 443 ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')) {
        ini_set('session.cookie_secure', 1);
    }
    
    session_start();
    
    if (isset($_SESSION['last_activity'])) {
        $inactivity_timeout = $session_lifetime;
        if ((time() - $_SESSION['last_activity']) > $inactivity_timeout) {
            session_unset();
            session_destroy();
            session_start();
        }
    }
    $_SESSION['last_activity'] = time();
    
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    } elseif ((time() - $_SESSION['last_regeneration']) > 86400) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

/**
 * Busca uma configuração do sistema
 */
function getSystemSetting($chave, $default = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT valor FROM configuracoes_sistema WHERE chave = ?");
        $stmt->execute([$chave]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['valor'] : $default;
    } catch (PDOException $e) {
        error_log("Erro ao buscar configuração: " . $e->getMessage());
        return $default;
    }
}

/**
 * Salva ou atualiza uma configuração do sistema
 */
function setSystemSetting($chave, $valor) {
    global $pdo;
    if (!$pdo) {
        error_log("setSystemSetting: PDO não está disponível");
        return false;
    }
    try {
        $stmt_check = $pdo->prepare("SELECT id FROM configuracoes_sistema WHERE chave = ?");
        $stmt_check->execute([$chave]);
        $exists = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if ($exists) {
            try {
                $stmt = $pdo->prepare("UPDATE configuracoes_sistema SET valor = ?, updated_at = CURRENT_TIMESTAMP WHERE chave = ?");
                $stmt->execute([$valor, $chave]);
            } catch (PDOException $e) {
                $stmt = $pdo->prepare("UPDATE configuracoes_sistema SET valor = ? WHERE chave = ?");
                $stmt->execute([$valor, $chave]);
            }
        } else {
            $stmt = $pdo->prepare("INSERT INTO configuracoes_sistema (chave, valor) VALUES (?, ?)");
            $stmt->execute([$chave, $valor]);
        }
        return true;
    } catch (PDOException $e) {
        error_log("setSystemSetting: " . $e->getMessage());
        return false;
    }
}

/**
 * Busca todas as configurações do sistema
 */
function getAllSystemSettings() {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT chave, valor FROM configuracoes_sistema");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $settings = [];
        foreach ($results as $row) {
            $settings[$row['chave']] = $row['valor'];
        }
        return $settings;
    } catch (PDOException $e) {
        error_log("Erro ao buscar todas as configurações: " . $e->getMessage());
        return [];
    }
}

/**
 * Obtém a versão atual da plataforma
 */
function get_platform_version() {
    $version_file = __DIR__ . '/../VERSION.txt';
    if (file_exists($version_file)) {
        $version = trim(file_get_contents($version_file));
        return !empty($version) ? $version : '1.0.0';
    }
    return '1.0.0';
}

// Carrega sistema de plugins
if (file_exists(__DIR__ . '/../helpers/plugin_hooks.php')) {
    require_once __DIR__ . '/../helpers/plugin_hooks.php';
}
if (file_exists(__DIR__ . '/../helpers/plugin_loader.php')) {
    require_once __DIR__ . '/../helpers/plugin_loader.php';
}

// Carregar migration helper para executar migrations durante instalação
if (file_exists(__DIR__ . '/../helpers/migration_helper.php')) {
    require_once __DIR__ . '/../helpers/migration_helper.php';
}

// Carregar sistema SaaS se habilitado
if (file_exists(__DIR__ . '/../saas/includes/saas_functions.php')) {
    require_once __DIR__ . '/../saas/includes/saas_functions.php';
    if (function_exists('saas_enabled') && saas_enabled()) {
        if (file_exists(__DIR__ . '/../saas/includes/saas_limits.php')) {
            require_once __DIR__ . '/../saas/includes/saas_limits.php';
        }
        if (file_exists(__DIR__ . '/../saas/saas.php')) {
            require_once __DIR__ . '/../saas/saas.php';
        }
    }
}

// Aplicar headers de segurança
if (!headers_sent()) {
    if (file_exists(__DIR__ . '/security_headers.php')) {
        require_once __DIR__ . '/security_headers.php';
        if (function_exists('apply_security_headers')) {
            apply_security_headers(false);
        }
    }
}
?>
PHP;
        
        $configContent = str_replace(
            ['{DB_HOST}', '{DB_USER}', '{DB_PASS}', '{DB_NAME}'],
            [
                addslashes($dbConfig['host']),
                addslashes($dbConfig['user']),
                addslashes($dbConfig['pass'] ?? ''),
                addslashes($dbConfig['name'])
            ],
            $configTemplate
        );
        
        if (!file_put_contents($configPath, $configContent)) {
            throw new Exception('Não foi possível criar o arquivo config.php');
        }
        
        // 2. Conectar ao banco de dados
        $pdo = new PDO(
            "mysql:host={$dbConfig['host']};dbname={$dbConfig['name']};charset=utf8mb4",
            $dbConfig['user'],
            $dbConfig['pass'] ?? ''
        );
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("SET time_zone = '-03:00';");
        
        // 3. Executar migrations para criar estrutura do banco de dados
        $migrationsDir = dirname(__DIR__) . '/migrations';
        $migrationHelperPath = dirname(__DIR__) . '/helpers/migration_helper.php';
        
        // Verificar se migration_helper.php existe e carregar novamente após download do código
        if (file_exists($migrationHelperPath) && !function_exists('run_migrations')) {
            require_once $migrationHelperPath;
            error_log("INSTALADOR: migration_helper.php carregado do caminho: {$migrationHelperPath}");
        }
        
        // Verificar se a pasta de migrations existe
        if (!is_dir($migrationsDir)) {
            error_log("INSTALADOR: AVISO - Pasta de migrations não encontrada: {$migrationsDir}");
            error_log("INSTALADOR: Usando estrutura mínima do banco de dados como fallback.");
            $sqlContent = getMinimalDatabaseSQL();
            executeSQL($pdo, $sqlContent);
        } else {
            // Verificar se a função run_migrations está disponível
            if (!function_exists('run_migrations')) {
                error_log("INSTALADOR: ERRO - Função run_migrations não encontrada após carregar migration_helper.php");
                error_log("INSTALADOR: Caminho do helper: {$migrationHelperPath}");
                error_log("INSTALADOR: Helper existe? " . (file_exists($migrationHelperPath) ? 'SIM' : 'NÃO'));
                error_log("INSTALADOR: Usando estrutura mínima como fallback.");
                $sqlContent = getMinimalDatabaseSQL();
                executeSQL($pdo, $sqlContent);
            } else {
                // Executar todas as migrations
                error_log("INSTALADOR: Executando migrations para criar estrutura do banco de dados...");
                error_log("INSTALADOR: Pasta de migrations: {$migrationsDir}");
                
                // Contar quantas migrations existem
                $migrationFiles = glob($migrationsDir . '/*.php');
                $migrationCount = count($migrationFiles);
                error_log("INSTALADOR: Total de arquivos de migration encontrados: {$migrationCount}");
                
                try {
                    $migrationResults = run_migrations($pdo, '1.0.0');
                } catch (Exception $e) {
                    error_log("INSTALADOR: EXCEÇÃO ao executar migrations: " . $e->getMessage());
                    error_log("INSTALADOR: Stack trace: " . $e->getTraceAsString());
                    $migrationResults = [
                        'executed' => [],
                        'skipped' => [],
                        'errors' => [['migration' => 'system', 'error' => $e->getMessage()]]
                    ];
                }
                
                // Verificar resultados
                $migrationsExecuted = count($migrationResults['executed']);
                $migrationsSkipped = count($migrationResults['skipped']);
                $migrationsErrors = count($migrationResults['errors']);
                
                error_log("INSTALADOR: Migrations executadas: {$migrationsExecuted}");
                error_log("INSTALADOR: Migrations ignoradas: {$migrationsSkipped}");
                error_log("INSTALADOR: Migrations com erro: {$migrationsErrors}");
                
                if ($migrationsSkipped > 0) {
                    error_log("INSTALADOR: Migrations ignoradas (já executadas): {$migrationsSkipped}");
                }
                
                if ($migrationsErrors > 0) {
                    error_log("INSTALADOR: AVISO - {$migrationsErrors} migration(s) falharam durante a instalação.");
                    foreach ($migrationResults['errors'] as $error) {
                        $migrationName = $error['migration'] ?? 'desconhecida';
                        $errorMsg = $error['error'] ?? 'Erro desconhecido';
                        error_log("INSTALADOR:   - Migration {$migrationName}: {$errorMsg}");
                    }
                    // Continuar mesmo com erros, mas logar
                    // Se houver muitos erros críticos, pode ser necessário usar fallback
                    $criticalErrors = 0;
                    foreach ($migrationResults['errors'] as $error) {
                        $errorMsg = strtolower($error['error'] ?? '');
                        // Erros que não são críticos (já existe, duplicado, etc)
                        if (strpos($errorMsg, 'already exists') === false && 
                            strpos($errorMsg, 'duplicate') === false &&
                            strpos($errorMsg, 'já existe') === false) {
                            $criticalErrors++;
                        }
                    }
                    
                    if ($criticalErrors > 0 && $migrationsExecuted == 0) {
                        error_log("INSTALADOR: ERRO CRÍTICO - Nenhuma migration foi executada com sucesso. Usando estrutura mínima como fallback.");
                        $sqlContent = getMinimalDatabaseSQL();
                        executeSQL($pdo, $sqlContent);
                    }
                }
                
                // Se nenhuma migration foi executada e nenhuma foi ignorada, pode ser que não existam migrations
                if ($migrationsExecuted == 0 && $migrationsSkipped == 0 && $migrationsErrors == 0) {
                    error_log("INSTALADOR: AVISO - Nenhuma migration encontrada. Usando estrutura mínima como fallback.");
                    $sqlContent = getMinimalDatabaseSQL();
                    executeSQL($pdo, $sqlContent);
                } else if ($migrationsExecuted > 0) {
                    error_log("INSTALADOR: Sucesso - {$migrationsExecuted} migration(s) executadas com sucesso durante a instalação.");
                }
            }
        }
        
        // 4. Criar usuário administrador (obrigatório)
        if (empty($adminData['nome']) || empty($adminData['email']) || empty($adminData['senha'])) {
            throw new Exception('Dados do administrador são obrigatórios. Por favor, preencha nome, email e senha.');
        }
        
        // Verificar estrutura da tabela usuarios para garantir que não há coluna email
        try {
            $stmt = $pdo->query("SHOW COLUMNS FROM usuarios LIKE 'email'");
            $hasEmailColumn = $stmt->rowCount() > 0;
            if ($hasEmailColumn) {
                error_log("INSTALADOR: AVISO - Tabela usuarios tem coluna 'email', mas não deveria ter.");
            }
        } catch (PDOException $e) {
            error_log("INSTALADOR: Erro ao verificar colunas da tabela usuarios: " . $e->getMessage());
        }
        
        // Verificar se já existe admin
        $stmt = $pdo->query("SELECT id FROM usuarios WHERE tipo = 'admin' LIMIT 1");
        $existingAdmin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Usar email como usuário (a tabela usuarios não tem coluna email, apenas usuario)
        $usuario = trim($adminData['email']);
        $senhaHash = password_hash($adminData['senha'], PASSWORD_DEFAULT);
        
        if ($existingAdmin) {
            // Atualizar admin existente
            $stmt = $pdo->prepare("
                UPDATE usuarios 
                SET nome = ?, usuario = ?, senha = ?
                WHERE id = ?
            ");
            $stmt->execute([
                trim($adminData['nome']),
                $usuario,
                $senhaHash,
                $existingAdmin['id']
            ]);
            error_log("INSTALADOR: Usuário admin atualizado com sucesso. Usuário: {$usuario}");
        } else {
            // Criar novo admin - IMPORTANTE: NÃO usar coluna 'email', apenas 'usuario'
            $stmt = $pdo->prepare("
                INSERT INTO usuarios (nome, usuario, senha, tipo) 
                VALUES (?, ?, ?, 'admin')
            ");
            $stmt->execute([
                trim($adminData['nome']),
                $usuario,
                $senhaHash
            ]);
            error_log("INSTALADOR: Usuário admin criado com sucesso. Usuário: {$usuario}");
        }
        
        // 5. Criar arquivo de lock
        $lockContent = "Instalado em: " . date('Y-m-d H:i:s') . "\n";
        $lockContent .= "Versão: " . (file_exists(dirname(__DIR__) . '/VERSION.txt') ? trim(file_get_contents(dirname(__DIR__) . '/VERSION.txt')) : '1.0.0') . "\n";
        file_put_contents($lockFile, $lockContent);
        
        // 6. Excluir pasta install após instalação bem-sucedida
        $installDir = __DIR__;
        error_log("INSTALADOR: Preparando para excluir pasta de instalação: {$installDir}");
        
        // Usar função de exclusão recursiva já existente
        try {
            delete_directory_recursive($installDir);
            error_log("INSTALADOR: Pasta de instalação excluída com sucesso.");
        } catch (Exception $e) {
            error_log("INSTALADOR: AVISO - Não foi possível excluir a pasta de instalação: " . $e->getMessage());
            error_log("INSTALADOR: Por favor, exclua manualmente a pasta 'install' por segurança.");
        }
        
        // 7. Limpar sessão de instalação
        session_start();
        unset($_SESSION['install_db']);
        unset($_SESSION['install_admin']);
        unset($_SESSION['install_github']);
        
        jsonResponse(true, ['message' => 'Instalação concluída com sucesso!']);
        
    } catch (Exception $e) {
        jsonResponse(false, [], $e->getMessage());
    }
}

/**
 * Executa SQL em blocos (suporta múltiplas queries)
 */
function executeSQL($pdo, $sql) {
    // Remove comentários e quebras de linha desnecessárias
    $sql = preg_replace('/--.*$/m', '', $sql);
    $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
    
    // Divide em queries individuais
    $queries = array_filter(array_map('trim', explode(';', $sql)));
    
    foreach ($queries as $query) {
        if (empty($query)) continue;
        
        try {
            $pdo->exec($query);
        } catch (PDOException $e) {
            // Ignorar erros de "já existe" mas logar outros
            if (strpos($e->getMessage(), 'already exists') === false && 
                strpos($e->getMessage(), 'Duplicate') === false) {
                error_log("Erro SQL: " . $e->getMessage() . " | Query: " . substr($query, 0, 100));
            }
        }
    }
}

/**
 * Retorna SQL mínimo do banco de dados (estrutura básica)
 * Isso será substituído pelo SQL completo do GitHub
 */
function getMinimalDatabaseSQL() {
    return <<<'SQL'
-- Estrutura mínima do banco de dados
-- NOTA: Este é um SQL básico. O SQL completo deve ser baixado do GitHub ou estar em install/database.sql

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `usuario` varchar(100) NOT NULL UNIQUE,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('admin','infoprodutor') NOT NULL DEFAULT 'infoprodutor',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `configuracoes_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chave` varchar(100) NOT NULL UNIQUE,
  `valor` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chave` (`chave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `migration_file` varchar(255) NOT NULL UNIQUE,
  `version` varchar(20) NOT NULL,
  `executed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration_file` (`migration_file`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
}

