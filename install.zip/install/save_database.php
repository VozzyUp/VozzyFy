<?php
/**
 * Endpoint para salvar dados do banco de dados
 * Retorna JSON para processamento via AJAX
 */

session_start();

header('Content-Type: application/json');

// Verificar se é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

// Verificar se dados foram enviados
if (empty($_POST['db_host']) || empty($_POST['db_user']) || empty($_POST['db_name'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Campos obrigatórios do banco de dados não preenchidos']);
    exit;
}

// Verificar dados do admin
if (empty($_POST['admin_nome']) || empty($_POST['admin_email']) || empty($_POST['admin_senha'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Campos obrigatórios do administrador não preenchidos']);
    exit;
}

if (strlen($_POST['admin_senha']) < 6) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'A senha deve ter no mínimo 6 caracteres']);
    exit;
}

// Salvar dados do BD na sessão
$_SESSION['install_db'] = [
    'host' => trim($_POST['db_host']),
    'user' => trim($_POST['db_user']),
    'pass' => trim($_POST['db_pass'] ?? ''),
    'name' => trim($_POST['db_name'])
];

// Salvar dados do admin na sessão
$_SESSION['install_admin'] = [
    'nome' => trim($_POST['admin_nome']),
    'email' => trim($_POST['admin_email']),
    'senha' => $_POST['admin_senha'] // Não fazer trim na senha
];

echo json_encode([
    'success' => true,
    'message' => 'Dados salvos com sucesso',
    'redirect' => '/install?step=4'
]);

