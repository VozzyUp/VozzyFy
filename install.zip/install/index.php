<?php
/**
 * Wizard de Instalação
 * Interface multi-step para instalação da plataforma
 */

// Iniciar sessão ANTES de qualquer output
session_start();

// Processar POSTs ANTES de qualquer include
// Verificar tanto GET quanto POST para o step
$currentStep = isset($_GET['step']) ? (int)$_GET['step'] : (isset($_POST['step']) ? (int)$_POST['step'] : 0);

// Debug: verificar se POST está chegando
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST recebido. Step: " . $currentStep . ", Token presente: " . (isset($_POST['github_token']) ? 'sim' : 'não'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $currentStep == 2 && !empty($_POST['github_token'])) {
    $githubToken = trim($_POST['github_token']);
    
    // Validar token testando conexão com GitHub
    $githubRepo = 'LeonardoIsrael0516/getfy';
    $githubBranch = 'main';
    $url = "https://api.github.com/repos/{$githubRepo}/contents/VERSION.txt?ref={$githubBranch}";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: PHP-Installer',
        'Authorization: token ' . $githubToken,
        'Accept: application/vnd.github.v3.raw'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    error_log("Validação token. HTTP Code: " . $httpCode . ", Error: " . $curlError);
    
    if ($httpCode === 200) {
        // Token válido, salvar e redirecionar
        $_SESSION['install_github'] = [
            'token' => $githubToken
        ];
        // Limpar qualquer output buffer
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        error_log("Token válido, redirecionando para step 3");
        header('Location: /install?step=3');
        exit;
    } else {
        // Token inválido, salvar erro na sessão
        $errorMsg = 'Token inválido ou sem permissões.';
        if ($httpCode === 401) {
            $errorMsg = 'Token inválido. Verifique se o token está correto.';
        } elseif ($httpCode === 403) {
            $errorMsg = 'Token sem permissões. Verifique se o token tem permissão "repo".';
        } elseif ($httpCode === 404) {
            $errorMsg = 'Repositório não encontrado. Verifique se o repositório está correto.';
        }
        $_SESSION['install_error'] = $errorMsg;
        // Limpar qualquer output buffer
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        error_log("Token inválido, redirecionando para step 2 com erro");
        header('Location: /install?step=2');
        exit;
    }
}

// Processar POST do passo 3 (banco de dados + admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $currentStep == 3 && !empty($_POST['db_host'])) {
    // Salvar dados do BD na sessão
    $_SESSION['install_db'] = [
        'host' => $_POST['db_host'],
        'user' => $_POST['db_user'],
        'pass' => $_POST['db_pass'] ?? '',
        'name' => $_POST['db_name']
    ];
    
    // Salvar dados do admin na sessão
    if (!empty($_POST['admin_nome']) && !empty($_POST['admin_email']) && !empty($_POST['admin_senha'])) {
        $_SESSION['install_admin'] = [
            'nome' => $_POST['admin_nome'],
            'email' => $_POST['admin_email'],
            'senha' => $_POST['admin_senha']
        ];
    }
    
    // Limpar qualquer output buffer
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Location: /install?step=4');
    exit;
}

// Verificar se já está instalado
$lockFile = dirname(__DIR__) . '/config/installed.lock';
if (file_exists($lockFile)) {
    header('Location: /');
    exit;
}

require_once __DIR__ . '/requirements.php';

$checker = new RequirementsChecker();

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$step = max(1, min(4, $step)); // Limitar entre 1 e 4

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Plataforma de Checkout</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2rem;
        }
        .step {
            flex: 1;
            text-align: center;
            position: relative;
        }
        .step::after {
            content: '';
            position: absolute;
            top: 20px;
            left: 50%;
            width: 100%;
            height: 2px;
            background: #e5e7eb;
            z-index: -1;
        }
        .step:last-child::after {
            display: none;
        }
        .step.active .step-number {
            background: #7427F1;
            color: white;
        }
        .step.completed .step-number {
            background: #10b981;
            color: white;
        }
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e5e7eb;
            color: #6b7280;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.5rem;
            font-weight: bold;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen py-12 px-4">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Instalação da Plataforma</h1>
            <p class="text-gray-600 mb-8">Siga os passos abaixo para instalar o sistema</p>
            
            <!-- Indicador de Passos -->
            <div class="step-indicator mb-8">
                <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">
                    <div class="step-number">1</div>
                    <div class="text-sm font-medium">Requisitos</div>
                </div>
                <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">
                    <div class="step-number">2</div>
                    <div class="text-sm font-medium">Acesso</div>
                </div>
                <div class="step <?php echo $step >= 3 ? 'active' : ''; ?> <?php echo $step > 3 ? 'completed' : ''; ?>">
                    <div class="step-number">3</div>
                    <div class="text-sm font-medium">Banco de Dados</div>
                </div>
                <div class="step <?php echo $step >= 4 ? 'active' : ''; ?>">
                    <div class="step-number">4</div>
                    <div class="text-sm font-medium">Instalação</div>
                </div>
            </div>
            
            <!-- Conteúdo do Passo -->
            <div class="step-content">
                <?php
                switch ($step) {
                    case 1:
                        include __DIR__ . '/step_requirements.php';
                        break;
                    case 2:
                        include __DIR__ . '/step_github.php';
                        break;
                    case 3:
                        include __DIR__ . '/step_database.php';
                        break;
                    case 4:
                        include __DIR__ . '/step_install.php';
                        break;
                }
                ?>
            </div>
        </div>
    </div>
    
    <!-- Rodapé -->
    <div class="max-w-4xl mx-auto mt-8 text-center">
        <p class="text-xs text-gray-500">
            Desenvolvido por 
            <a href="https://www.instagram.com/leonardoisraelbr/" target="_blank" rel="noopener noreferrer" class="text-purple-600 hover:text-purple-700 hover:underline">
                @leonardoisraelbr
            </a>
        </p>
    </div>
    
</body>
</html>

