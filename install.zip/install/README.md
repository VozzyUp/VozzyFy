# Sistema de Instalação e Atualização

## Instalação

### Acesso
Acesse `/install` no navegador para iniciar o processo de instalação.

### Requisitos
- PHP >= 7.4
- Extensões: PDO, pdo_mysql, curl, json, mbstring, openssl
- Permissões de escrita em: `config/`, `uploads/`, `backups/`, `temp/`

### Processo
1. **Verificação de Requisitos**: Sistema verifica automaticamente se todos os requisitos estão atendidos
2. **Configuração do Banco**: Informe credenciais do MySQL/MariaDB
3. **Usuário Admin**: Crie a conta de administrador inicial
4. **Instalação**: Sistema instala automaticamente o banco de dados e configura o sistema

### Arquivo SQL
O sistema tentará baixar `database.sql` do GitHub. Se não conseguir, usará uma estrutura mínima.
Para usar um arquivo local, coloque `database.sql` na pasta `install/`.

## Atualização

### Acesso
Acesse o painel admin → "Atualizações"

### Configuração GitHub
Configure as seguintes configurações do sistema:
- `github_repo`: Repositório no formato `usuario/repositorio`
- `github_token`: Token de autenticação GitHub (Personal Access Token)
- `github_branch`: Branch padrão (`main` ou `master`)

### Processo de Atualização
1. **Verificar Atualizações**: Compara versão local com GitHub
2. **Download**: Baixa arquivos atualizados
3. **Backup**: Cria backup automático do banco e arquivos críticos
4. **Atualização**: Substitui arquivos e executa migrations
5. **Conclusão**: Sistema atualizado

### Migrations
Migrations são arquivos PHP na pasta `migrations/` com formato:
- `YYYYMMDD_HHMMSS_description.php`
- Cada migration deve ter:
  - Classe `Migration_YYYYMMDD_HHMMSS_description`
  - Método `getVersion()`: Retorna versão mínima requerida
  - Método `up($pdo)`: Aplica mudanças
  - Método `down($pdo)`: Reverte mudanças (opcional)

### Backups
Backups são criados automaticamente antes de cada atualização em `backups/update_YYYYMMDD_HHMMSS/`.
O sistema mantém apenas os últimos 5 backups.

## Segurança

- Após instalação, a pasta `install/` é bloqueada via `.htaccess`
- Arquivo `config/installed.lock` previne reinstalação acidental
- Apenas administradores podem acessar sistema de atualização
- Backups automáticos antes de cada atualização

