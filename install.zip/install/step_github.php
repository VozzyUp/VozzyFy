<?php
/**
 * Passo 2: Configuração de Acesso
 */

// Verificar se há erro na sessão
$error = '';
if (isset($_SESSION['install_error'])) {
    $error = $_SESSION['install_error'];
    unset($_SESSION['install_error']);
}
?>

<div class="space-y-6">
    <h2 class="text-2xl font-semibold text-gray-900">Configuração de Acesso</h2>
    <p class="text-gray-600">Informe o token de acesso para baixar o código-fonte do sistema</p>
    
    <?php if (!empty($error)): ?>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4">
            <p class="text-red-800 text-sm"><?php echo htmlspecialchars($error); ?></p>
        </div>
    <?php endif; ?>
    
    <form id="github-token-form" method="POST" action="/install?step=2" class="space-y-4">
        <input type="hidden" name="step" value="2">
        <div>
            <label for="github_token" class="block text-sm font-medium text-gray-700 mb-1">
                Token de Acesso <span class="text-red-500">*</span>
            </label>
            <input 
                type="password" 
                id="github_token" 
                name="github_token" 
                value="<?php echo htmlspecialchars($_POST['github_token'] ?? (isset($_SESSION['install_github']['token']) ? $_SESSION['install_github']['token'] : '')); ?>"
                required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Digite o token de acesso"
            >
        </div>
        
        <div class="flex justify-between pt-4">
            <a href="/install?step=1" class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4">
                ← Voltar
            </a>
            <button 
                type="submit" 
                id="submit-token-btn"
                class="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-6 rounded-lg transition"
            >
                Próximo Passo →
            </button>
        </div>
    </form>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('github-token-form');
        const submitBtn = document.getElementById('submit-token-btn');
        
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const token = document.getElementById('github_token').value;
                if (!token) {
                    alert('Por favor, preencha o token de acesso');
                    return;
                }
                
                submitBtn.disabled = true;
                submitBtn.textContent = 'Validando...';
                
                const formData = new FormData();
                formData.append('step', '2');
                formData.append('github_token', token);
                
                fetch('/install/validate_token.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Token válido, redirecionar
                        window.location.href = data.redirect;
                    } else {
                        // Token inválido, mostrar erro na página
                        const errorDiv = document.querySelector('.error-message');
                        if (errorDiv) {
                            errorDiv.textContent = data.error || 'Token inválido';
                            errorDiv.parentElement.classList.remove('hidden');
                        } else {
                            // Criar div de erro se não existir
                            const form = document.getElementById('github-token-form');
                            const errorHtml = '<div class="bg-red-50 border border-red-200 rounded-lg p-4 error-message-container"><p class="text-red-800 text-sm error-message">' + (data.error || 'Token inválido') + '</p></div>';
                            form.insertAdjacentHTML('afterbegin', errorHtml);
                        }
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Próximo Passo →';
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao validar token: ' + error.message);
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Próximo Passo →';
                });
            });
        }
    });
    </script>
</div>

