<?php
/**
 * Passo 3: Configuração do Banco de Dados
 */

// Validar dados de acesso
// Sessão já foi iniciada no index.php, não precisa iniciar novamente

// Verificar se tem dados de acesso na sessão
if (empty($_SESSION['install_github'])) {
    // Se não tem dados de acesso na sessão, redirecionar
    header('Location: /install?step=2');
    exit;
}

// O processamento do POST já foi feito no index.php antes de qualquer output
?>

<div class="space-y-6">
    <h2 class="text-2xl font-semibold text-gray-900">Configuração do Banco de Dados</h2>
    <p class="text-gray-600">Informe as credenciais do banco de dados MySQL/MariaDB</p>
    
    <form id="db-form" method="POST" class="space-y-4">
        <input type="hidden" name="step" value="3">
        <div>
            <label for="db_host" class="block text-sm font-medium text-gray-700 mb-1">
                Host do Banco de Dados
            </label>
            <input 
                type="text" 
                id="db_host" 
                name="db_host" 
                value="<?php echo htmlspecialchars($_POST['db_host'] ?? 'localhost'); ?>"
                required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="localhost"
            >
        </div>
        
        <div>
            <label for="db_user" class="block text-sm font-medium text-gray-700 mb-1">
                Usuário do Banco de Dados
            </label>
            <input 
                type="text" 
                id="db_user" 
                name="db_user" 
                value="<?php echo htmlspecialchars($_POST['db_user'] ?? 'root'); ?>"
                required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="root"
            >
        </div>
        
        <div>
            <label for="db_pass" class="block text-sm font-medium text-gray-700 mb-1">
                Senha do Banco de Dados
            </label>
            <input 
                type="password" 
                id="db_pass" 
                name="db_pass" 
                value="<?php echo htmlspecialchars($_POST['db_pass'] ?? ''); ?>"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Deixe vazio se não houver senha"
            >
        </div>
        
        <div>
            <label for="db_name" class="block text-sm font-medium text-gray-700 mb-1">
                Nome do Banco de Dados
            </label>
            <input 
                type="text" 
                id="db_name" 
                name="db_name" 
                value="<?php echo htmlspecialchars($_POST['db_name'] ?? ''); ?>"
                required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="nome_do_banco"
            >
            <p class="text-sm text-gray-500 mt-1">O banco será criado automaticamente se não existir</p>
        </div>
        
        <div class="border-t border-gray-200 pt-6 mt-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Informações do Administrador</h3>
            <p class="text-sm text-gray-600 mb-4">Crie a conta do administrador do sistema</p>
            
            <div>
                <label for="admin_nome" class="block text-sm font-medium text-gray-700 mb-1">
                    Nome Completo <span class="text-red-500">*</span>
                </label>
                <input 
                    type="text" 
                    id="admin_nome" 
                    name="admin_nome" 
                    value="<?php echo htmlspecialchars($_POST['admin_nome'] ?? ''); ?>"
                    required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Nome do Administrador"
                >
            </div>
            
            <div class="mt-4">
                <label for="admin_email" class="block text-sm font-medium text-gray-700 mb-1">
                    E-mail <span class="text-red-500">*</span>
                </label>
                <input 
                    type="email" 
                    id="admin_email" 
                    name="admin_email" 
                    value="<?php echo htmlspecialchars($_POST['admin_email'] ?? ''); ?>"
                    required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="admin@exemplo.com"
                >
            </div>
            
            <div class="mt-4">
                <label for="admin_senha" class="block text-sm font-medium text-gray-700 mb-1">
                    Senha <span class="text-red-500">*</span>
                </label>
                <input 
                    type="password" 
                    id="admin_senha" 
                    name="admin_senha" 
                    required
                    minlength="6"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Mínimo 6 caracteres"
                >
                <p class="text-sm text-gray-500 mt-1">A senha deve ter no mínimo 6 caracteres</p>
            </div>
        </div>
        
        <div class="flex justify-between pt-4">
            <a href="/install?step=2" class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4">
                ← Voltar
            </a>
            <div class="space-x-3">
                <button 
                    type="button" 
                    id="test-connection-btn"
                    class="bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-2 px-6 rounded-lg transition"
                >
                    Testar Conexão
                </button>
                <button 
                    type="submit" 
                    id="submit-db-btn"
                    class="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-6 rounded-lg transition"
                >
                    Próximo Passo →
                </button>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const testBtn = document.getElementById('test-connection-btn');
    const dbForm = document.getElementById('db-form');
    const submitBtn = document.getElementById('submit-db-btn');
    
    // Teste de conexão
    if (testBtn && dbForm) {
        testBtn.addEventListener('click', function() {
            const dbHost = document.getElementById('db_host').value;
            const dbUser = document.getElementById('db_user').value;
            const dbPass = document.getElementById('db_pass').value;
            const dbName = document.getElementById('db_name').value;
            
            if (!dbHost || !dbUser || !dbName) {
                alert('Por favor, preencha pelo menos Host, Usuário e Nome do Banco de Dados');
                return;
            }
            
            testBtn.disabled = true;
            testBtn.textContent = 'Testando...';
            
            const formData = new FormData();
            formData.append('db_host', dbHost);
            formData.append('db_user', dbUser);
            formData.append('db_pass', dbPass);
            formData.append('db_name', dbName);
            
            fetch('/install/installer.php?action=test_connection', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                testBtn.disabled = false;
                testBtn.textContent = 'Testar Conexão';
                
                if (data.success) {
                    alert('Conexão bem-sucedida!');
                } else {
                    alert('Erro: ' + (data.error || 'Não foi possível conectar'));
                }
            })
            .catch(error => {
                testBtn.disabled = false;
                testBtn.textContent = 'Testar Conexão';
                alert('Erro ao testar conexão: ' + error.message);
            });
        });
    }
    
    // Submit do formulário via AJAX
    if (dbForm && submitBtn) {
        dbForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const dbHost = document.getElementById('db_host').value;
            const dbUser = document.getElementById('db_user').value;
            const dbPass = document.getElementById('db_pass').value;
            const dbName = document.getElementById('db_name').value;
            const adminNome = document.getElementById('admin_nome').value;
            const adminEmail = document.getElementById('admin_email').value;
            const adminSenha = document.getElementById('admin_senha').value;
            
            if (!dbHost || !dbUser || !dbName) {
                alert('Por favor, preencha pelo menos Host, Usuário e Nome do Banco de Dados');
                return;
            }
            
            if (!adminNome || !adminEmail || !adminSenha) {
                alert('Por favor, preencha todos os campos do administrador');
                return;
            }
            
            if (adminSenha.length < 6) {
                alert('A senha deve ter no mínimo 6 caracteres');
                return;
            }
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Salvando...';
            
            const formData = new FormData();
            formData.append('step', '3');
            formData.append('db_host', dbHost);
            formData.append('db_user', dbUser);
            formData.append('db_pass', dbPass);
            formData.append('db_name', dbName);
            formData.append('admin_nome', adminNome);
            formData.append('admin_email', adminEmail);
            formData.append('admin_senha', adminSenha);
            
            fetch('/install/save_database.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Dados salvos, redirecionar
                    window.location.href = data.redirect;
                } else {
                    // Erro ao salvar
                    alert('Erro: ' + (data.error || 'Não foi possível salvar os dados'));
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Próximo Passo →';
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                alert('Erro ao salvar dados: ' + error.message);
                submitBtn.disabled = false;
                submitBtn.textContent = 'Próximo Passo →';
            });
        });
    }
});
</script>

