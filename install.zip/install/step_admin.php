<?php
/**
 * Passo 4: Informações do Administrador (Opcional)
 */

// Validar dados do banco de dados
if (empty($_SESSION['install_db'])) {
    header('Location: /install?step=3');
    exit;
}
?>

<div class="space-y-6">
    <h2 class="text-2xl font-semibold text-gray-900">Informações do Administrador</h2>
    <p class="text-gray-600">O sistema já possui um usuário administrador padrão configurado no banco de dados.</p>
    
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p class="text-blue-800 text-sm">
            <strong>Nota:</strong> Você pode usar o usuário administrador padrão que já está configurado no banco de dados, 
            ou preencher os campos abaixo para criar um novo administrador (opcional).
        </p>
    </div>
    
    <form method="POST" action="/install?step=5" class="space-y-4">
        <div>
            <label for="admin_nome" class="block text-sm font-medium text-gray-700 mb-1">
                Nome Completo (Opcional)
            </label>
            <input 
                type="text" 
                id="admin_nome" 
                name="admin_nome" 
                value="<?php echo htmlspecialchars($_POST['admin_nome'] ?? ''); ?>"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Deixe vazio para usar o padrão"
            >
        </div>
        
        <div>
            <label for="admin_email" class="block text-sm font-medium text-gray-700 mb-1">
                E-mail (Opcional)
            </label>
            <input 
                type="email" 
                id="admin_email" 
                name="admin_email" 
                value="<?php echo htmlspecialchars($_POST['admin_email'] ?? ''); ?>"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Deixe vazio para usar o padrão"
            >
        </div>
        
        <div class="flex justify-between pt-4">
            <a href="/install?step=3" class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4">
                ← Voltar
            </a>
            <button 
                type="submit" 
                class="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-6 rounded-lg transition"
            >
                Iniciar Instalação →
            </button>
        </div>
    </form>
</div>

