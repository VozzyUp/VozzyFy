<?php
/**
 * Verificador de Requisitos do Sistema
 * Verifica se o ambiente atende aos requisitos mínimos para instalação
 */

class RequirementsChecker {
    private $errors = [];
    private $warnings = [];
    private $requirements = [];
    
    public function __construct() {
        $this->checkAll();
    }
    
    /**
     * Verifica todos os requisitos
     */
    private function checkAll() {
        $this->checkPHPVersion();
        $this->checkPHPExtensions();
        $this->checkWritableDirectories();
        $this->checkAlreadyInstalled();
    }
    
    /**
     * Verifica versão do PHP
     */
    private function checkPHPVersion() {
        $minVersion = '7.4.0';
        $currentVersion = PHP_VERSION;
        
        if (version_compare($currentVersion, $minVersion, '<')) {
            $this->errors[] = "PHP {$minVersion} ou superior é necessário. Versão atual: {$currentVersion}";
        } else {
            $this->requirements['php_version'] = [
                'status' => 'ok',
                'current' => $currentVersion,
                'required' => $minVersion
            ];
        }
    }
    
    /**
     * Verifica extensões PHP necessárias
     */
    private function checkPHPExtensions() {
        $required = [
            'pdo' => 'PDO',
            'pdo_mysql' => 'PDO MySQL',
            'curl' => 'cURL',
            'json' => 'JSON',
            'mbstring' => 'mbstring',
            'openssl' => 'OpenSSL'
        ];
        
        foreach ($required as $ext => $name) {
            if (!extension_loaded($ext)) {
                $this->errors[] = "Extensão PHP '{$name}' ({$ext}) não está instalada";
            } else {
                $this->requirements['extensions'][$ext] = [
                    'status' => 'ok',
                    'name' => $name
                ];
            }
        }
    }
    
    /**
     * Verifica permissões de escrita em diretórios
     */
    private function checkWritableDirectories() {
        $dirs = [
            'config' => 'Configurações',
            'uploads' => 'Uploads',
            'backups' => 'Backups',
            'temp' => 'Temporários'
        ];
        
        $basePath = dirname(__DIR__);
        
        foreach ($dirs as $dir => $name) {
            $path = $basePath . '/' . $dir;
            
            // Criar diretório se não existir
            if (!is_dir($path)) {
                if (!@mkdir($path, 0755, true)) {
                    $this->errors[] = "Não foi possível criar o diretório '{$name}' ({$dir})";
                    continue;
                }
            }
            
            // Verificar permissões de escrita
            if (!is_writable($path)) {
                $this->errors[] = "O diretório '{$name}' ({$dir}) não tem permissão de escrita";
            } else {
                $this->requirements['directories'][$dir] = [
                    'status' => 'ok',
                    'name' => $name,
                    'path' => $path
                ];
            }
        }
    }
    
    /**
     * Verifica se já está instalado
     */
    private function checkAlreadyInstalled() {
        $lockFile = dirname(__DIR__) . '/config/installed.lock';
        $configFile = dirname(__DIR__) . '/config/config.php';
        
        if (file_exists($lockFile)) {
            $this->errors[] = "O sistema já está instalado. Remova o arquivo 'config/installed.lock' para reinstalar.";
        }
        
        // Verificar se config.php existe e tem configurações válidas
        if (file_exists($configFile)) {
            // Tentar incluir e verificar se PDO está configurado
            try {
                $configContent = file_get_contents($configFile);
                if (strpos($configContent, 'DB_HOST') !== false && strpos($configContent, 'DB_NAME') !== false) {
                    $this->warnings[] = "Arquivo config.php já existe. Ele será preservado durante a instalação.";
                }
            } catch (Exception $e) {
                // Ignorar erro
            }
        }
    }
    
    /**
     * Retorna se todos os requisitos foram atendidos
     */
    public function isReady() {
        return empty($this->errors);
    }
    
    /**
     * Retorna erros encontrados
     */
    public function getErrors() {
        return $this->errors;
    }
    
    /**
     * Retorna avisos encontrados
     */
    public function getWarnings() {
        return $this->warnings;
    }
    
    /**
     * Retorna todos os requisitos verificados
     */
    public function getRequirements() {
        return $this->requirements;
    }
    
    /**
     * Retorna resumo em formato JSON
     */
    public function toArray() {
        return [
            'ready' => $this->isReady(),
            'errors' => $this->errors,
            'warnings' => $this->warnings,
            'requirements' => $this->requirements
        ];
    }
}

// Se chamado diretamente, retorna JSON
if (php_sapi_name() !== 'cli' && basename($_SERVER['PHP_SELF']) === 'requirements.php') {
    header('Content-Type: application/json');
    $checker = new RequirementsChecker();
    echo json_encode($checker->toArray(), JSON_PRETTY_PRINT);
    exit;
}

